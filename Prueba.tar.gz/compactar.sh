tar -cvf Prueba.tar.gz *
