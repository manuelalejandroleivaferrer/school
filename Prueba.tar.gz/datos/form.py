from django.forms import *
from .models import *


class formulario_profesor(ModelForm):
	class Meta:
		model=Profesores
		fields='__all__'

			
		widgets = {			
			'nombre_profesor':TextInput(attrs={'class' :'form-control input-lg','required':'true'}),
			
            
			
		}
class formulario_grupo(ModelForm):
	class Meta:
		model=Grupo
		fields='__all__'

		#error_messages={
		#	'numero_inventario':{
		#		'unique':("Ya existe una PC con ese numero de inventario"),
		#	},
		#}		
		widgets = {			
			'nombre':TextInput(attrs={'class' :'form-control input-lg','required':'true'}),
			'profesor_guia':Select(attrs={'class' :'form-control input-sm select2-multiple','id':'select2-single-input-sm3'}),
            
			
		}



class formulario_estudiante(ModelForm):
	class Meta:
		model=Estudiante
		fields='__all__'

		#error_messages={
		#	'numero_inventario':{
		#		'unique':("Ya existe una PC con ese numero de inventario"),
		#	},
		#}		
		widgets = {			
			'nombre':TextInput(attrs={'class' :'form-control input-lg'}),
			'email':TextInput(attrs={'class' :'form-control input-lg'}),
			'ciudad':Select(attrs={'class' :'form-control input-sm select2-multiple','id':'select2-single-input-sm3'}),			
			'edad':TextInput(attrs={'class' :'form-control input-lg'}),
			'fecha_naciemiento':TextInput(attrs={'class' :' form-control input-lg date date-picker'}),
			'sexo':Select(attrs={'class' :'form-control input-sm select2-multiple','id':'select2-single-input-sm3'}),			

			
            
			
		}	
		
	
		

