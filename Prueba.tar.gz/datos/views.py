from django.http.response import HttpResponseRedirect
from datos.models import Grupo
from django.db.models.query_utils import Q
from django.shortcuts import render

#from .serializer import *
from .form import *
from django.core.paginator import EmptyPage, Paginator, InvalidPage,PageNotAnInteger
# Create your views here.

valor=10
def inicio(request):
    gruos=Grupo.objects.all()
    profesoresa=Profesores.objects.all()
    return render(request,'portrait1.html',{'grupos':gruos,'profesores':profesoresa})


def paginr(request,lista,cantidad):	
	page = request.GET.get('page')	
	
	paginator = Paginator(lista.order_by('id'), cantidad)	
	try:
		posts = paginator.page(page)		
	except PageNotAnInteger:
		posts = paginator.page(1)
	except EmptyPage:
		posts = paginator.page(paginator.num_pages)			
	return posts

def grupos(request):
    grupos=Grupo.objects.all()
    objeto=paginr(request,grupos,valor)
    return render(request,'gruposa/grupos.html',{'lp':objeto})


def profesoresass(request):
	profesores=Profesores.objects.all()
	objeto=paginr(request,profesores,valor)

	return render(request,'profesores/profesores.html',{'lp':objeto,'formulario_profesor':formulario_profesor})

def del_profesor(request,id_profesor):
	data_profesor=Profesores.objects.get(id=id_profesor)
	data_profesor.delete()
	return HttpResponseRedirect('/datos/profesores')

def insert_profesores(request):    
	if request.method=="POST":
		form_profesor=formulario_profesor(request.POST)
		if form_profesor.is_valid():
			form=form_profesor.save(commit=False)            
			form.save()            
			return HttpResponseRedirect('/datos/profesores')        
		else:	
			return render(request,'profesores/profesores.html',{'form_profesor':form_profesor} )
	return render(request,'profesores/profesores.html',{'form_profesor':formulario_profesor} )

def ed_profesor(request,id_profesore):
	datos_profesores=Profesores.objects.get(id=id_profesore)
	if request.method == 'POST':
		form_profesor=formulario_profesor(request.POST,instance=datos_profesores)
		if form_profesor.is_valid():
			form=form_profesor.save(commit=False)
			form.save()
			return HttpResponseRedirect('/datos/profesores')
		else:
			return render(request,'profesores/edit.html',{'form_profesor':form_profesor,'datos':datos_profesores} )
	form_profesore=formulario_profesor(instance=datos_profesores)
	return render(request,'profesores/edit.html',{'form_profesor':form_profesore,'datos':datos_profesores})




def insert_groups(request):    
	if request.method=="POST":
		form_grupos=formulario_grupo(request.POST)
		if form_grupos.is_valid():
			form=form_grupos.save(commit=False)            
			form.save()            
			return HttpResponseRedirect('/datos/grupos')        
		else:	
			return render(request,'gruposa/create.html',{'form_grupos':form_grupos} )

	return render(request,'gruposa/create.html',{'form_grupos':formulario_grupo} ) 
def del_grupo(request,id_grupo):
	data_grupo=Grupo.objects.get(id=id_grupo)	
	data_grupo.delete()
	return HttpResponseRedirect('/datos/grupos')
def ed_grupo(request,id_grupa):
	datos=Grupo.objects.get(id=id_grupa)
	if request.method == 'POST':
		form_grupo=formulario_grupo(request.POST,instance=datos)
		if form_grupo.is_valid():
			form=form_grupo.save(commit=False)
			form.save()
			return HttpResponseRedirect('/datos/grupos')
		else:
			return render(request,'gruposa/edit.html',{'form_grupos':form_grupo,'datos':datos} )
	form_grupos=formulario_grupo(instance=datos)
	return render(request,'gruposa/edit.html',{'form_grupos':form_grupos,'datos':datos})



def buscar_grupo(request):
        if request.method=='POST':
            buscadore=request.POST['search']
            consulta=Grupo.objects.filter(Q(nombre__contains=buscadore)|
                                                            Q(profesor_guia__nombre_profesor__contains=buscadore)
                                                            
                                                        )
        
            if not len(buscadore):
                error="!Debe insertar algun dato  a buscar."
                return render(request,'gruposa/grupos.html',{'error':error})
            elif not len(consulta):
                error="! Se encontraron "+str(len(consulta))+" "+ "coincidencias de lo que andaba buscando"
                return render(request,'gruposa/grupos.html',{'error':error})
            else:			
                post=paginr(request,consulta,valor)			
                return render(request,'gruposa/grupos.html',{'lp':post})


			
		
	
    
def grupos_estudiantes(request,id_grupos):
    data_grupos=Grupo.objects.get(id=id_grupos)
    data_estudiante=data_grupos.estudiante_grupo.all()
    post=paginr(request,data_estudiante,valor)
    return render(request,'estudiantes/estudiantes.html',{'lp':post,'grupo':data_grupos})


def del_estudiante(request,id_estudiante):
	estudiante=Estudiante.objects.get(id=id_estudiante)
	data_estudiante=estudiante
	estudiante.delete()
	return HttpResponseRedirect('/datos/grupos_estudiantes/%s'%(data_estudiante.grupo.id))


def insertar_estudiante(request,id_grupo):
	grupo=Grupo.objects.get(id=id_grupo)
	if request.method == 'POST':		
		form_estudiante=formulario_estudiante(request.POST)
		if form_estudiante.is_valid():
			form=form_estudiante.save(commit=False)
			form.grupo=grupo
			form.save()
			return HttpResponseRedirect('/datos/grupos_estudiantes/%s'%(grupo.id))
		else:
			return render(request,'estudiantes/create.html',{'form_estudiante':form_estudiante,'grupo':grupo} )
	return render(request,'estudiantes/create.html',{'form_estudiante':formulario_estudiante,'grupo':grupo})

def editar_estudiantes(request,id_estudiantes):
	estudiante=Estudiante.objects.get(id=id_estudiantes)	
	if request.method == 'POST':
		form_estudiante=formulario_estudiante(request.POST,instance=estudiante)
		a=estudiante.grupo	
		
		if form_estudiante.is_valid():
			form=form_estudiante.save(commit=False)
			form.grupo=a
			form.save()
			return HttpResponseRedirect('/datos/grupos_estudiantes/%s'%(a.id))
		else:
			return render(request,'estudiantes/edit_estudiantes.html',{'form_estudiante':form_estudiante,'datos':estudiante} )
	form_estudiante=formulario_estudiante(instance=estudiante)
	return render(request,'estudiantes/edit_estudiantes.html',{'form_estudiante':form_estudiante,'datos':estudiante})

def buscar_profesores(request):
	if request.method=='POST':
		buscadore=request.POST['search']
		consulta=Profesores.objects.filter(Q(nombre_profesor__contains=buscadore)
														
														
													)
	
		if not len(buscadore):
			error="!Debe insertar algun dato  a buscar."
			return render(request,'profesores/profesores.html',{'error':error})
		elif not len(consulta):
			error="! Se encontraron "+str(len(consulta))+" "+ "coincidencias de lo que andaba buscando"
			return render(request,'profesores/profesores.html',{'error':error})
		else:			
			post=paginr(request,consulta,valor)			
			return render(request,'profesores/profesores.html',{'lp':post})


def buscar_estudiantes(request):
	if request.method=='POST':
		buscadore=request.POST['search']
		consulta=Estudiante.objects.filter(Q(nombre__contains=buscadore)|
														Q(email__contains=buscadore)														
													)
	
		if not len(buscadore):
			error="!Debe insertar algun dato  a buscar."
			return render(request,'estudiantes/estudiantes.html',{'error':error})
		elif not len(consulta):
			error="! Se encontraron "+str(len(consulta))+" "+ "coincidencias de lo que andaba buscando"
			return render(request,'estudiantes/estudiantes.html',{'error':error})
		else:			
			post=paginr(request,consulta,valor)			
			return render(request,'estudiantes/estudiantes.html',{'lp':post})




	

    

    
    

