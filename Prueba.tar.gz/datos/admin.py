from django.contrib import admin

# Register your models here.
from .models import *

admin.site.register(Profesores)
admin.site.register(Grupo)
admin.site.register(Estudiante)
