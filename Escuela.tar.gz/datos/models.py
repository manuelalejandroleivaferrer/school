from django.db import models

from .ciudades import *
from .validator import *
# Create your models here.

class Profesores(models.Model):
	nombre_profesor=models.CharField('Nombre del Profesor',max_length=256,blank=True,null=True)
	def __str__(self):
        	return '%s' % (self.nombre_profesor)



class Grupo(models.Model):
    nombre=models.CharField('Nombre del Grupo',max_length=256,blank=True,null=True)
    profesor_guia=models.ForeignKey(Profesores,related_name="grupos_grupo",blank=True,null=True, on_delete=models.CASCADE)
    def __str__(self):
        return '%s' % (self.nombre)



class Estudiante (models.Model):
    sexo_estudiante='Masculino'
    Escojer_sexo=(
        ('Masculino','Masculino'),
		('Femenino','Femenino'),
    )


    nombre=models.CharField('Nombre del Estudiante',validators=[validate_name],max_length=256,blank=True,null=True)
    email=models.CharField('Email',unique=True,validators=[validate_email],max_length=255,blank=True,null=True)
    ciudad=models.CharField('Ciudad del Estudiante',max_length=256,blank=True,null=True,default=ciudades,choices=Escojer_cuidades)
    fecha_naciemiento=models.DateField('Fecha de Nacimiento',blank=True,null=True)
    edad=models.IntegerField('Edad',blank=True,null=True)
    sexo=models.CharField('Sexo del Estudiante',max_length=256,blank=True,null=True,default=sexo_estudiante,choices=Escojer_sexo)
    grupo=models.ForeignKey(Grupo,related_name="estudiante_grupo",blank=True,null=True, on_delete=models.CASCADE)

    def __str__(self):
        return '%s' % (self.nombre)

