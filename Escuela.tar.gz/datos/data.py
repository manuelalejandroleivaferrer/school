from urllib.request import urlopen
import json
from re import search

r = urlopen("http://www.europamundo.com/json/spain_america.json.txt")
a=r.read()


def data_json():
    json_data=json.loads(a)
    b=[]
    for i,j in json_data.items():  
        if search('ciudades',i):
            for s in j:
                b.append(s['c'])
    return tuple(b)

r.close()

