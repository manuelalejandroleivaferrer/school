from .data import data_json


ciudades='Cuba'



Escojer_cuidades=(
    (j,j)  for i,j in enumerate(data_json())) 