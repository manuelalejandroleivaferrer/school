from django.urls import path
from .views import *


urlpatterns = [
	###URL de los profesores
	path('profesores', profesoresass ),
	path('per_profesor', insert_profesores ),
	path('ed_profesor/<int:id_profesore>', ed_profesor ),
	path('del_profesor/<int:id_profesor>', del_profesor ),
	path('s_profesores', buscar_profesores ),

]+[
	###URL de los grupos
	path('grupos', grupos ),	
	path('per_grupos', insert_groups ),
	path('ed_grupos/<int:id_grupa>', ed_grupo ),    
	path('del_grupo/<int:id_grupo>', del_grupo ),    
	path('s_grupo', buscar_grupo ),

]+[

	###URL de los estudiantes
	path('grupos_estudiantes/<int:id_grupos>', grupos_estudiantes ),
	path('del_estudiante/<int:id_estudiante>', del_estudiante ),
	path('per_estudiantes/<int:id_grupo>', insertar_estudiante ),
	path('ed_estudiantes/<int:id_estudiantes>', editar_estudiantes ),
	path('s_estudiantes', buscar_estudiantes ),
	



]
