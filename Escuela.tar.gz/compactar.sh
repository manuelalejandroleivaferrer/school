tar -cvf SIE.tar.gz *
